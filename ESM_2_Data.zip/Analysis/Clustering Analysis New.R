library(readxl)
library(dplyr)
library(ggplot2)
library(writexl)

data <- read_excel("GVA_Panel_Data.xlsx",sheet = "DeltaLQ",col_names = TRUE)

# Check structure
str(data)

# Region identifiers
regions <- data$NUTS

X <- data %>%
  select(-NUTS)

# Convert blanks to NA, then numeric
X <- X %>%
  mutate(across(everything(), ~ na_if(as.character(.x), ""))) %>%
  mutate(across(everything(), as.numeric))

# Replace Inf and -Inf with NA
X <- X %>%
  mutate(across(everything(), ~ ifelse(is.infinite(.x), NA, .x)))

# Replace remaining NA / NaN with 0
X[is.na(X)] <- 0
X[is.nan(as.matrix(X))] <- 0

# Check if anything invalid remains
sum(!is.finite(as.matrix(X)))

# Remove only zero-variance columns (not zeros!)
X <- X[, sapply(X, function(col) sd(col) > 0)]

# Scale variables
X_scaled <- scale(X)

# K-means elbow method
set.seed(123)

max_k <- 10
wss <- numeric(max_k)

for (k in 1:max_k) {
  km <- kmeans(X_scaled, centers = k, nstart = 25)
  wss[k] <- km$tot.withinss
}

elbow_df <- data.frame(
  k = 1:max_k,
  wss = wss
)

# Plot elbow curve
elbow_plot <- ggplot(elbow_df, aes(x = k, y = wss)) +
  geom_line(color = "black") +
  geom_point(color = "black") +
  geom_vline(xintercept = max_k, linetype = "dotted", color = "black") +
  labs(
    title = "Elbow Method for Choosing Number of Clusters",
    x = "Number of Clusters (k)",
    y = "Total Within-Cluster Sum of Squares"
  ) +
  theme_minimal()

print(elbow_plot)

# Save elbow plot
ggsave(
  filename = "elbow_plot_delta.png",
  plot = elbow_plot,
  width = 8,
  height = 5,
  dpi = 300
)

# Hierarchical clustering
k_opt <- 3
dist_matrix <- dist(X_scaled, method = "euclidean")

hc <- hclust(
  dist_matrix,
  method = "ward.D2"
)

# Cut tree into selected number of clusters
clusters <- cutree(hc, k = k_opt)

# Add cluster labels to data
cluster_result <- data %>%
  mutate(cluster = clusters)

# Cluster size table
cluster_sizes <- cluster_result %>%
  count(cluster, name = "regions")

print(cluster_sizes)


# Dendrogram
png(
  filename = "dendrogram_clusters_delta.png",
  width = 5000,
  height = 900
)

plot(
  hc,
  labels = regions,
  main = paste("Dendrogram of NUTS-2 Regions, k =", k_opt),
  xlab = "",
  sub = "",
  cex = 1
)

rect.hclust(
  hc,
  k = k_opt,
  border = "black"
)

dev.off()

# Also display in RStudio
plot(
  hc,
  labels = regions,
  main = paste("Dendrogram of NUTS-2 Regions, k =", k_opt),
  xlab = "",
  sub = "",
  cex = 0.3
)

rect.hclust(
  hc,
  k = k_opt,
  border = "black"
)

# 7. List of cluster components
cluster_components <- cluster_result %>%
  select(NUTS, cluster) %>%
  arrange(cluster, NUTS)

print(cluster_components)

# Create one row per cluster with all NUTS regions listed
cluster_list <- cluster_components %>%
  group_by(cluster) %>%
  summarise(
    nuts_regions = paste(NUTS, collapse = ", "),
    number_of_regions = n(),
    .groups = "drop"
  )

print(cluster_list)

# Export results
write_xlsx(
  list(
    cluster_assignment = cluster_components,
    cluster_list = cluster_list,
    cluster_sizes = cluster_sizes,
    elbow_values = elbow_df
  ),
  "clustering_results_logLQratio.xlsx"
)