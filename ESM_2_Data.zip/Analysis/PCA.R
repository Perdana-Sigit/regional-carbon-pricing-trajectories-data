library(readxl)
library(dplyr)
library(ggplot2)
library(ggrepel)
library(factoextra)

data <- read_excel("Clustering_Variables.xlsx", sheet = "Top50", col_names = TRUE)

regions <- data$nuts

X <- data %>%
  select(
    starts_with("InitShare2017_Base_"),
    starts_with("TaxShareResponse_"),
    starts_with("AvgContributionResponse_"),
    Delta_Entropy_2050,
    Delta_HHI_2050,
    Tax_Induced_Turnover
  )

X <- X %>%
  mutate(across(everything(), ~ na_if(as.character(.x), ""))) %>%
  mutate(across(everything(), as.numeric))

X <- X %>%
  mutate(across(everything(), ~ ifelse(is.infinite(.x), NA, .x)))

# Remove columns that are completely missing
X <- X[, colSums(!is.na(X)) > 0]

# Replace NA with column median, not zero
X <- X %>%
  mutate(across(
    everything(),
    ~ ifelse(is.na(.x), median(.x, na.rm = TRUE), .x)
  ))

# Remove zero variance columns
X <- X[, sapply(X, function(col) sd(col, na.rm = TRUE) > 1e-10)]

# Scale variables
X_scaled <- scale(X)

# PCA
pca_result <- prcomp(
  X_scaled,
  center = FALSE,
  scale. = FALSE
)

# Summary
summary(pca_result)

##Need accumulated 70%-80% variance
cum_var <- cumsum(
  summary(pca_result)$importance[2,]
)

cum_var

num_pc <- which(cum_var >= 0.75)[1]

num_pc

scores <- as.data.frame(
  pca_result$x[, 1:15]
)

data_pca <- cbind(
  data,
  scores
)


# Loadings
loadings <- as.data.frame(pca_result$rotation)
loadings$Variable <- rownames(loadings)

# PCA scores
scores <- as.data.frame(pca_result$x)
data_pca <- cbind(data_pca, scores)

# Scree plot
fviz_eig(pca_result, addlabels = TRUE)

# Variable contribution plot
fviz_pca_var(
  pca_result,
  col.var = "contrib",
  repel = TRUE
)

# Individual regions in PCA space
fviz_pca_ind(
  pca_result,
  geom = "point",
  repel = TRUE
)

# Example regression using first 5 PCs
model <- lm(
  delta_gva_pct ~ PC1 + PC2 + PC3 + PC4 + PC5,
  data = data_pca
)

summary(model)

# Clustering
library(cluster)

# Use retained PCs
scores <- as.data.frame(
  pca_result$x[,1:7]
)

# Distance matrix
d <- dist(
  scores,
  method = "euclidean"
)

# Hierarchical clustering
hc <- hclust(
  d,
  method = "ward.D2"
)

# Plot dendrogram
plot(
  hc,
  labels = FALSE,
  hang = -1,
  main = "Hierarchical clustering"
)


clusters3 <- cutree(
  hc,
  k = 3
)

clusters4 <- cutree(
  hc,
  k = 4
)

clusters5 <- cutree(
  hc,
  k = 5
)

table(clusters3)

table(clusters4)

table(clusters5)


#plot
library(ggplot2)
library(dplyr)
library(ggrepel)

data_plot <- data %>%
  mutate(
    fossil_axis = fossil_industry_share + fossil_elec_share,
    green_axis = solar_share + wind_share + biomass_share,
    gva_status = ifelse(delta_gva_pct < 0, "Loss", "Gain")
  )

plot1 <- ggplot(data_plot, aes(
  x = hhi_d3,
  y = krugman_country_d3,
  color = gva_status,
  label = nuts
)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey60") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey60") +
  geom_point(size = 2.5, alpha = 0.85) +
  geom_text_repel(size = 3, max.overlaps = 40) +
  scale_color_manual(
    values = c("Loss" = "red", "Gain" = "green")
  ) +
  labs(
    title = "Regional Structures",
    x = "hhi_d3",
    y = "krugman_country_d3",
    color = "GVA impact"
  ) +
  theme_minimal()

ggsave(
  filename = "regional_typology_plot3.png",
  plot = plot1,
  width = 12,
  height = 8,
  dpi = 300
)
