library(readxl)
library(dplyr)

data <- read_excel(
  "Trajectory_Explanation_Variables_Wide2.xlsx",
  sheet = "Final_Wide"
)

data$Group <- as.factor(data$Group)

# Check group sizes
table(data$Group)

# Variables to test
vars_to_test <- c(
  "Wind_Potential",
  "Solar_Potential",
  "Biomass_Potential",
  "Baseline_LQ_Fossil_Extraction_2017",
  "Baseline_LQ_Fossil_Electricity_2017",
  "Baseline_LQ_Carbon_Intensive_Industry_2017",
  "Baseline_LQ_Wind_Electricity_2017",
  "Baseline_LQ_Solar_Electricity_2017",
  "Baseline_LQ_Biomass_Electricity_2017",
  "DS_LQ_Fossil_Extraction_2030",
  "DS_LQ_Fossil_Electricity_2030",
  "DS_LQ_Carbon_Intensive_Industry_2030",
  "DS_LQ_Wind_Electricity_2030",
  "DS_LQ_Solar_Electricity_2030",
  "DS_LQ_Biomass_Electricity_2030",
  "DS_LQ_Fossil_Extraction_2050",
  "DS_LQ_Fossil_Electricity_2050",
  "DS_LQ_Carbon_Intensive_Industry_2050",
  "DS_LQ_Wind_Electricity_2050",
  "DS_LQ_Solar_Electricity_2050",
  "DS_LQ_Biomass_Electricity_2050",
  "DS_Wind_LQ_Change_2017_2050",
  "DS_Solar_LQ_Change_2017_2050",
  "DS_Biomass_LQ_Change_2017_2050",
  "DS_Wind_LQ_Change_2030_2050",
  "DS_Solar_LQ_Change_2030_2050",
  "DS_Biomass_LQ_Change_2030_2050",
  "DS_SCI_2017_2030",
  "DS_SCI_2030_2050",
  "Avg_Sector_Contribution_Pct_Sector_1",
  "Avg_Sector_Contribution_Pct_Sector_2",
  "Avg_Sector_Contribution_Pct_Sector_3",
  "Avg_Sector_Contribution_Pct_Sector_4",
  "Avg_Sector_Contribution_Pct_Sector_5",
  "Avg_Sector_Contribution_Pct_Sector_7",
  "Avg_Sector_Contribution_Pct_Sector_8",
  "Avg_Sector_Contribution_Pct_Sector_9",
  "Avg_Sector_Contribution_Pct_Sector_10",
  "Avg_Sector_Contribution_Pct_Sector_11",
  "Avg_Sector_Contribution_Pct_Sector_12",
  "Avg_Sector_Contribution_Pct_Sector_13",
  "Avg_Sector_Contribution_Pct_Sector_SOL",
  "Avg_Sector_Contribution_Pct_Sector_WIN",
  "Avg_Sector_Contribution_Pct_Sector_BIO",
  "Avg_Sector_Contribution_Pct_Sector_OTH",
  "Avg_Sector_Contribution_Pct_Sector_COA",
  "Avg_Sector_Contribution_Pct_Sector_OIP",
  "Avg_Sector_Contribution_Pct_Sector_GAP",
  "DeltaLQ_1",
  "DeltaLQ_2",
  "DeltaLQ_3",
  "DeltaLQ_4",
  "DeltaLQ_5",
  "DeltaLQ_7",
  "DeltaLQ_8",
  "DeltaLQ_9",
  "DeltaLQ_10",
  "DeltaLQ_11",
  "DeltaLQ_12",
  "DeltaLQ_13",
  "DeltaLQ_SOL",
  "DeltaLQ_WIN",
  "DeltaLQ_BIO",
  "DeltaLQ_OTH",
  "DeltaLQ_COA",
  "DeltaLQ_OIP",
  "DeltaLQ_GAP",
  "DeltaLQ_HYD",
  "DeltaLQ_NUC"
)

# Kruskal Wallis tests
kw_results <- data.frame(
  Variable = character(),
  Chi_square = numeric(),
  df = numeric(),
  p_value = numeric()
)

for(v in vars_to_test){
  test <- kruskal.test(
    as.formula(paste(v, "~ Group")),
    data = data
  )
  
  kw_results <- rbind(
    kw_results,
    data.frame(
      Variable = v,
      Chi_square = as.numeric(test$statistic),
      df = as.numeric(test$parameter),
      p_value = test$p.value
    )
  )
}

kw_results

# Add significance stars
kw_results <- kw_results %>%
  mutate(
    Significance = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01 ~ "**",
      p_value < 0.05 ~ "*",
      p_value < 0.1 ~ ".",
      TRUE ~ ""
    )
  )

kw_results