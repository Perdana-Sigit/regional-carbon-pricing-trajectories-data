library(readxl)
library(dplyr)
library(factoextra)
library(readxl)

data <- read_excel("GVA_Panel_Data.xlsx", sheet = "Delta per capita", col_names = TRUE)

regions <- data$nuts
X <- data[, -1]
str(X)

# scale 
X_scaled <- scale(X)

# compute distance matrix
dist_matrix <- dist(X_scaled, method = "euclidean")

# hierarchical clustering
hc <- hclust(dist_matrix, method = "ward.D2")

# Basic dendrogram
png("dendrogram.png", width = 1200, height = 800)
plot(hc,
     labels = regions,
     main = "Dendrogram of Regions",
     xlab = "",
     sub = "",
     cex = 0.2)

dev.off()

clusters <- cutree(hc, k = 5)
plot(hc, labels = regions, cex = 0.2)
rect.hclust(hc, k = 5, border = "green")
table(clusters)

# dendrogram with 5 clusters
png("dendrogram_normalized_contribution.png", width = 1200, height = 800)

plot(hc,
     labels = data$nuts,
     cex = 0.2,
     main = "Dendrogram (5 clusters)",
     xlab = "",
     sub = "")

rect.hclust(hc, k = 5, border = "red")

dev.off()

# long format for plotting
cluster_long <- cluster_profile %>%
  pivot_longer(
    cols = -cluster,
    names_to = "feature",
    values_to = "mean_value"
  )

# heatmap
p <- ggplot(cluster_long, aes(x = feature, y = factor(cluster), fill = mean_value)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(
    low = "blue",
    mid = "white",
    high = "red",
    midpoint = 0
  ) +
  theme_minimal() +
  labs(
    title = "Cluster Profiles Based on Normalized Contributions",
    x = "Feature",
    y = "Cluster",
    fill = "Mean contribution"
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1)
  )

ggsave("heatmap.png", plot = p, width = 12, height = 10, dpi = 300)

# list of nuts in each cluster
data$cluster <- clusters
split(data$nuts, data$cluster)

