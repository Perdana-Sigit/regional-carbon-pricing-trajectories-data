### Plot the GDP change per capita
library(readxl)
data <- read_excel("GVA_change_per_capita_D3.xlsx", col_names = TRUE)
names(data)[names(data) == "total GVA change per capita"] <- "GVA_change_per_capita"

library(ggplot2)

# Histogram
ggplot(data, aes(x = GVA_change_per_capita)) +
  geom_histogram(bins = 150, fill = "grey70", color = "white") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "red") +
  labs(
    x = "Total GVA change per capita (USD)",
    y = "Number of regions",
  ) +
  theme_minimal() +
  theme(
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank()
  )

ggsave("histogram.png", width = 8, height = 6, dpi = 300)

# Density with only top 50 (no middle nuts)
data <- data[order(data$welfare_usd), ]
data_subset <- data[data$group != "middle", ]

ggplot(data_subset, aes(x = welfare_usd, color = group, fill = group)) +
  geom_density(alpha = 0.3) +
  geom_vline(xintercept = 0, linetype = "dashed") +
  labs(
    x = "Welfare change per capita (USD)",
    y = "Distribution density",
  ) +
  theme_minimal() +
  theme(
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank()
  )

ggsave("Top 50 density.png", width = 8, height = 6, dpi = 300)


### 2017 sector share
library(readxl)
library(dplyr)
library(tidyr)
library(ggplot2)

data_2017 <- read_excel("GVA_2017.xlsx", col_names = TRUE)

all_cols <- c("01","02","03","04","05","07","08","09","10","11","12","13",
              "COA","OIP","GAP","NUC","HYD","SOL","WIN","BIO","OTH")

# compute sector share
data_2017[all_cols] <- data_2017[all_cols] / rowSums(data_2017[all_cols], na.rm = TRUE)

# compute share mean
data_subset <- data_2017 %>%
  filter(Group != "middle")

sector_means <- data_subset %>%
  group_by(Group) %>%
  summarise(across(all_of(all_cols), ~ mean(.x, na.rm = TRUE)))

# reshape
sector_long <- sector_means %>%
  pivot_longer(cols = -Group, names_to = "sector", values_to = "share")

# name sector in full name
sector_labels <- c(
  "01" = "Coal extraction",
  "02" = "Crude oil extraction",
  "03" = "Natural gas",
  "04" = "Petroleum products",
  "05" = "Electricity T&D",
  "07" = "Agriculture",
  "08" = "Energy-intensive industries",
  "09" = "Other manufacturing",
  "10" = "Land transport",
  "11" = "Sea transport",
  "12" = "Air transport",
  "13" = "Services",
  "COA" = "Coal-fired power",
  "OIP" = "Oil-fired power",
  "GAP" = "Gas-fired power",
  "NUC" = "Nuclear power",
  "HYD" = "Hydropower",
  "SOL" = "Solar PV",
  "WIN" = "Wind power",
  "BIO" = "Biomass",
  "OTH" = "Other sources"
)

# plot
plot_sector_group <- function(cols, title_text, file_name) {
  
  plot_data <- sector_long %>%
    filter(sector %in% cols) %>%
    mutate(
      sector_label = recode(sector, !!!sector_labels),
      share = share * 100
    )
  
  p <- ggplot(plot_data, aes(x = sector_label, y = share, fill = Group)) +
    geom_bar(stat = "identity", position = "dodge") +
    labs(
      x = NULL,
      y = "Average 2017 GVA share (%)",
      title = title_text,
      fill = "Group"
    ) +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank()
    )
  
  print(p)
  ggsave(file_name, plot = p, width = 8, height = 5, dpi = 300)
}

# plot six graphs
plot_sector_group(c("COA", "OIP", "GAP", "OTH"),
                  "2017 Fossil Energy Shares",
                  "plot_1_fossil_energy.png")

plot_sector_group(c("NUC", "HYD", "SOL", "WIN", "BIO"),
                  "2017 Renewable Energy Shares",
                  "plot_2_renewable_energy.png")

plot_sector_group(c("08", "09"),
                  "2017 Manufacturing Industry Shares",
                  "plot_3_industry.png")

plot_sector_group(c("10", "11", "12"),
                  "2017 Transport Shares",
                  "plot_4_transport.png")

plot_sector_group(c("13"),
                  "2017 Services Share",
                  "plot_5_services.png")

plot_sector_group(c("01", "02", "03", "04", "05", "07"),
                  "2017 Remaining Sector Shares",
                  "plot_6_remaining.png")